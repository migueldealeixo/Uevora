package com.t2.t2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class T2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
