package com.t2.t2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class T2Application {

	public static void main(String[] args) {
		SpringApplication.run(T2Application.class, args);
	}

}
